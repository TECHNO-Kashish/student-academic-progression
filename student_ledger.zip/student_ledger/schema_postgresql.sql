CREATE TABLE student (
	student_id SERIAL NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	email VARCHAR(120), 
	dob DATE, 
	status VARCHAR(15) DEFAULT 'ACTIVE' NOT NULL, 
	PRIMARY KEY (student_id), 
	CONSTRAINT ck_student_name CHECK (name <> ''), 
	CONSTRAINT ck_student_status CHECK (status IN ('ACTIVE','DROPPED','PASSED_OUT')), 
	UNIQUE (email)
);

CREATE TABLE organizer (
	organizer_id SERIAL NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	PRIMARY KEY (organizer_id), 
	UNIQUE (name)
);

CREATE TABLE subject (
	subject_id SERIAL NOT NULL, 
	code VARCHAR(20) NOT NULL, 
	name VARCHAR(120) NOT NULL, 
	sem_no INTEGER NOT NULL, 
	kind VARCHAR(10) NOT NULL, 
	credits INTEGER NOT NULL, 
	max_marks INTEGER NOT NULL, 
	PRIMARY KEY (subject_id), 
	CONSTRAINT ck_subj_sem CHECK (sem_no BETWEEN 1 AND 8), 
	CONSTRAINT ck_subj_kind CHECK (kind IN ('THEORY','LAB')), 
	CONSTRAINT ck_subj_credits CHECK (credits > 0), 
	CONSTRAINT ck_subj_max CHECK (max_marks > 0), 
	UNIQUE (code)
);

CREATE TABLE board_result (
	result_id SERIAL NOT NULL, 
	student_id INTEGER NOT NULL, 
	level VARCHAR(20) NOT NULL, 
	board_name VARCHAR(80) NOT NULL, 
	passing_year INTEGER NOT NULL, 
	percentage NUMERIC(5, 2) NOT NULL, 
	PRIMARY KEY (result_id), 
	CONSTRAINT ck_board_level CHECK (level IN ('SECONDARY','HIGHER_SECONDARY')), 
	CONSTRAINT ck_board_pct CHECK (percentage BETWEEN 0 AND 100), 
	CONSTRAINT ck_board_year CHECK (passing_year BETWEEN 1990 AND 2100), 
	CONSTRAINT uq_board_student_level UNIQUE (student_id, level), 
	FOREIGN KEY(student_id) REFERENCES student (student_id) ON DELETE CASCADE
);

CREATE TABLE semester (
	sem_id SERIAL NOT NULL, 
	student_id INTEGER NOT NULL, 
	sem_no INTEGER NOT NULL, 
	academic_year INTEGER NOT NULL, 
	sgpa NUMERIC(4, 2) NOT NULL, 
	result_status VARCHAR(10) DEFAULT 'PASS' NOT NULL, 
	PRIMARY KEY (sem_id), 
	CONSTRAINT ck_sem_status CHECK (result_status IN ('PASS','ATKT','FAIL','ONGOING')), 
	CONSTRAINT ck_sem_no CHECK (sem_no BETWEEN 1 AND 8), 
	CONSTRAINT ck_sem_sgpa CHECK (sgpa BETWEEN 0 AND 10), 
	CONSTRAINT ck_sem_year CHECK (academic_year BETWEEN 2000 AND 2100), 
	CONSTRAINT uq_sem_student_no UNIQUE (student_id, sem_no), 
	FOREIGN KEY(student_id) REFERENCES student (student_id) ON DELETE CASCADE
);

CREATE TABLE gap_year (
	gap_id SERIAL NOT NULL, 
	student_id INTEGER NOT NULL, 
	start_year INTEGER NOT NULL, 
	kind VARCHAR(10) NOT NULL, 
	reason VARCHAR(200), 
	PRIMARY KEY (gap_id), 
	CONSTRAINT ck_gap_kind CHECK (kind IN ('DROP','GAP')), 
	CONSTRAINT ck_gap_year CHECK (start_year BETWEEN 2000 AND 2100), 
	CONSTRAINT uq_gap_student_year UNIQUE (student_id, start_year), 
	FOREIGN KEY(student_id) REFERENCES student (student_id) ON DELETE CASCADE
);

CREATE TABLE mark (
	mark_id SERIAL NOT NULL, 
	student_id INTEGER NOT NULL, 
	subject_id INTEGER NOT NULL, 
	marks NUMERIC(6, 2) NOT NULL, 
	PRIMARY KEY (mark_id), 
	CONSTRAINT ck_mark_nonneg CHECK (marks >= 0), 
	CONSTRAINT uq_mark_student_subject UNIQUE (student_id, subject_id), 
	FOREIGN KEY(student_id) REFERENCES student (student_id) ON DELETE CASCADE, 
	FOREIGN KEY(subject_id) REFERENCES subject (subject_id) ON DELETE RESTRICT
);

CREATE TABLE activity (
	activity_id SERIAL NOT NULL, 
	student_id INTEGER NOT NULL, 
	organizer_id INTEGER, 
	title VARCHAR(150) NOT NULL, 
	category VARCHAR(20) NOT NULL, 
	scope VARCHAR(10), 
	activity_date DATE, 
	details VARCHAR(300), 
	PRIMARY KEY (activity_id), 
	CONSTRAINT ck_act_cat CHECK (category IN ('SEMINAR','CO_CURRICULAR','EXTRA_CURRICULAR')), 
	CONSTRAINT ck_act_scope CHECK (scope IS NULL OR scope IN ('INTERNAL','EXTERNAL')), 
	CONSTRAINT ck_act_seminar_scope CHECK ((category = 'SEMINAR' AND scope IS NOT NULL) OR (category <> 'SEMINAR' AND scope IS NULL)), 
	FOREIGN KEY(student_id) REFERENCES student (student_id) ON DELETE CASCADE, 
	FOREIGN KEY(organizer_id) REFERENCES organizer (organizer_id) ON DELETE SET NULL
);

