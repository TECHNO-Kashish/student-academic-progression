# Student Academic & Activity Ledger: User Guide

## 1. Setup
```
pip install -r requirements.txt
python seed.py            # creates tables + sample data (optional)
streamlit run app.py
```
**Database:** defaults to a local SQLite file. For PostgreSQL/MySQL, create an empty database, then set
`DATABASE_URL` (e.g. `postgresql+psycopg2://user:pass@localhost/ledger` or `mysql+pymysql://user:pass@localhost/ledger`).
Tables are created automatically; plain DDL is in `schema_postgresql.sql` / `schema_mysql.sql`.

**Google Sheet:** create a Google Cloud service account, download its JSON key, share your sheet with the
service-account email (Editor), then set `GOOGLE_CREDS=/path/key.json` and `GSHEET_ID=<id from sheet URL>`.
Without these, sync uses `ledger_sync.xlsx` instead (same behaviour).

## 2. Schema (3NF)
`student` → `board_result`, `semester`, `gap_year`, `mark`, `activity`; `subject` → `mark`; `organizer` → `activity`.
Every non-key column depends only on its own table's key; organisers, subjects and boards are stored once and referenced by ID.

## 3. Constraints
| Table | Rule | Violation result |
|---|---|---|
| all | Primary keys, NOT NULL, FK to `student` with **ON DELETE CASCADE** | deleting a student removes their data |
| student | `status IN (ACTIVE, DROPPED, PASSED_OUT)` (current status, default ACTIVE) | rejected |
| semester | `result_status IN (PASS, ATKT, FAIL, ONGOING)` (semester status, default PASS); `sgpa BETWEEN 0 AND 10`, `sem_no 1–8`, one row per (student, sem) | rejected |
| board_result | `percentage 0–100`, level ∈ {SECONDARY, HIGHER_SECONDARY}, one per level | rejected |
| mark | `marks >= 0`; also `marks <= subject.max_marks` (checked in code) | rejected |
| mark → subject | **ON DELETE RESTRICT** | can't delete a subject that has marks |
| activity | category ∈ {SEMINAR, CO_CURRICULAR, EXTRA_CURRICULAR}; seminars **must** have scope INTERNAL/EXTERNAL, others **must not** | rejected |
| activity → organizer | **ON DELETE SET NULL** | activity kept, organiser blank |
| gap_year | kind ∈ {DROP, GAP}, one per (student, year) | rejected |

## 4. Using the app
- **Dashboard:** type a name in the search bar → pick the student → see the current status badge, board results, the SGPA/CGPA progression curve
  (red shaded band + ✕ marks each drop/gap year) semester-wise status table, and subject/lab marks per semester.
  CGPA is the running average of SGPAs.
- **Edit data:** choose a table, edit cells / add a row at the bottom / select a row and press Delete, then **Save changes**.
  Rejected rows are listed with the reason; valid rows are saved. Leave the ID blank for new rows.
- **Activities:** four tabs: internal seminars, external seminars, technical/co-curricular, extra-curricular.
- **Sync:** every save automatically pushes DB → sheet. The sheet also has the four segregated activity tabs.

## 5. Editing from the spreadsheet (two-way sync)
Edit cells in the table tabs (not the four activity view tabs), keep the ID column, then press **Pull sheet → DB**.
Each row goes through the same constraints. Invalid rows are rejected and listed in the app, and the sheet is
overwritten with the database values, so bad data never persists. Deleting rows in the sheet does **not** delete
from the DB (use the Edit tab).

## 6. Direct SQL
Changes made directly in the DB obey the same constraints. Press **Push DB → sheet** afterwards to refresh the sheet.
