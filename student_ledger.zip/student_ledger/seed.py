import random, datetime as dt
import db
db.md.drop_all(db.engine); db.init_db(); random.seed(7)
S = lambda t, **k: db.save_row(t, k)
for n, e in [("Aarav Patil", "aarav@example.com"), ("Diya Sharma", "diya@example.com"), ("Rohan Mehta", "rohan@example.com")]:
    S("student", name=n, email=e, dob=dt.date(2004, 5, 1), status={"Rohan Mehta": "DROPPED"}.get(n, "ACTIVE"))
for sid in (1, 2, 3):
    S("board_result", student_id=sid, level="SECONDARY", board_name="Maharashtra SSC", passing_year=2020, percentage=random.randint(80, 96))
    S("board_result", student_id=sid, level="HIGHER_SECONDARY", board_name="Maharashtra HSC", passing_year=2022, percentage=random.randint(70, 92))
for sem in range(1, 5):
    for k, (nm, kind, mx, cr) in enumerate([("Engineering Mathematics", "THEORY", 100, 3), ("Core Subject", "THEORY", 100, 3), ("Core Subject Lab", "LAB", 50, 1)]):
        S("subject", code=f"S{sem}{k}", name=f"{nm} {sem}", sem_no=sem, kind=kind, credits=cr, max_marks=mx)
for sid in (1, 2, 3):
    for subj in range(1, 13):
        mx = 50 if subj % 3 == 0 else 100
        S("mark", student_id=sid, subject_id=subj, marks=round(mx * random.uniform(.55, .95), 1))
# Aarav has a drop year (2024-25) between sem 4 and 5
for sem, yr, g, r in [(1, 2022, 7.4, "PASS"), (2, 2022, 7.9, "PASS"), (3, 2023, 8.1, "PASS"),
                       (4, 2023, 6.9, "ATKT"), (5, 2025, 8.3, "PASS"), (6, 2025, 8.7, "ONGOING")]:
    S("semester", student_id=1, sem_no=sem, academic_year=yr, sgpa=g, result_status=r)
S("gap_year", student_id=1, start_year=2024, kind="DROP", reason="Dropped year to reappear for backlog")
for sem, yr, g in [(1, 2022, 8.5), (2, 2022, 8.8), (3, 2023, 9.0), (4, 2023, 8.7)]:
    S("semester", student_id=2, sem_no=sem, academic_year=yr, sgpa=g, result_status="ONGOING" if sem == 4 else "PASS")
for sem, yr, g in [(1, 2022, 6.8), (2, 2022, 7.1), (3, 2023, 7.5)]:
    S("semester", student_id=3, sem_no=sem, academic_year=yr, sgpa=g, result_status="FAIL" if sem == 3 else "PASS")
for o in ("VIVA Institute", "IIT Bombay", "IEEE Mumbai Section", "College Sports Council"): S("organizer", name=o)
for sid, org, title, cat, scope, d in [
    (1, 1, "Power Electronics Seminar", "SEMINAR", "INTERNAL", dt.date(2023, 9, 4)),
    (1, 2, "Techfest Talk on EVs", "SEMINAR", "EXTERNAL", dt.date(2023, 12, 20)),
    (1, 3, "Arduino Workshop", "CO_CURRICULAR", None, dt.date(2024, 2, 11)),
    (2, 4, "Inter-college Cricket", "EXTRA_CURRICULAR", None, dt.date(2023, 1, 15)),
    (2, 1, "Smart Grid Seminar", "SEMINAR", "INTERNAL", dt.date(2023, 10, 9)),
    (3, 3, "PCB Design Contest", "CO_CURRICULAR", None, dt.date(2023, 3, 3))]:
    S("activity", student_id=sid, organizer_id=org, title=title, category=cat, scope=scope, activity_date=d)
print("Seeded.")
